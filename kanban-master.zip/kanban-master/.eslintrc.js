module.exports = {
  root: true,
  extends: [
    '@indielayer/eslint-config-vue'
  ]
}
