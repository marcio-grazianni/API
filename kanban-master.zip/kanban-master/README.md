## Commands
#### `npm install`
> Installs package dependencies

#### `npm run dev` or `npm run serve` 
> Compiles and hot-reloads for development

#### `npm run build`
> Compiles and minifies for production

#### `npm run lint`
> Lints and fixes files
