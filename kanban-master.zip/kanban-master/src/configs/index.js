import icons from './icons'

export default {
  icons
}
