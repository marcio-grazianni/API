export default [{
  id: 1,
  title: 'fix: 💭 channel label on chat app',
  description: 'we need it bolder',
  order: 1,
  state: 'TODO'
}, {
  id: 2,
  title: 'feature: new emojis on board 🤘',
  description: 'we need it for reasons 🤤',
  order: 0,
  state: 'TODO'
}, {
  id: 3,
  title: 'feature: add stripe account on signup',
  description: '',
  order: 1,
  state: 'TESTING'
}, {
  id: 4,
  title: 'refactor: scroll 📜 directive on big pages',
  description: 'remember to check the scroll',
  order: 0,
  state: 'INPROGRESS'
}, {
  id: 5,
  title: 'feature: add big cards on dashboard',
  description: 'everyone loves cards',
  order: 3,
  state: 'TODO'
}]
